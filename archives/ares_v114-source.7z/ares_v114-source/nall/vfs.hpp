#pragma once

#include <nall/vfs/vfs.hpp>
