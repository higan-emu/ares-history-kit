#pragma once

namespace nall {

template<typename T> struct view;

}
