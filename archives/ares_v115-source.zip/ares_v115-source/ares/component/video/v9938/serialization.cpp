auto V9938::serialize(serializer& s) -> void {
}
