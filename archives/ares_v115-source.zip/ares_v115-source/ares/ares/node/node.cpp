namespace ares::Core {
  #include <ares/node/video/sprite.cpp>
  #include <ares/node/video/screen.cpp>
  #include <ares/node/audio/stream.cpp>
}
