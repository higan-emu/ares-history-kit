struct System : Object {
  DeclareClass(System, "System")
  using Object::Object;
};
