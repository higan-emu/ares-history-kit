struct Component : Object {
  DeclareClass(Component, "Component")
  using Object::Object;
};
