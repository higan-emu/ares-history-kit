#include <fc/fc.hpp>

namespace ares::Famicom {

#include "port.cpp"
#include "gamepad/gamepad.cpp"

}
