#pragma once

void msg_error(const char * err, ...);
void msg_warning(const char* err, ...);
void msg_debug(const char* err, ...);
