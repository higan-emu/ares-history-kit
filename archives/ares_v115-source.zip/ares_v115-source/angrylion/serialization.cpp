auto RDP::serialize(serializer& s) -> void {
  Thread::serialize(s);
}
