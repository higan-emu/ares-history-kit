auto Expansion::serialize(serializer& s) -> void {
}
