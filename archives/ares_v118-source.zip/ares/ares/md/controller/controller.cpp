#include <md/md.hpp>

namespace ares::MegaDrive {

#include "port.cpp"
#include "control-pad/control-pad.cpp"
#include "fighting-pad/fighting-pad.cpp"

}
