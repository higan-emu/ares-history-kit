struct Input : Object {
  DeclareClass(Input, "input")
  using Object::Object;
};
