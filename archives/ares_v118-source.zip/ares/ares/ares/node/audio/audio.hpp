struct Audio : Object {
  DeclareClass(Audio, "audio")
  using Object::Object;
};
