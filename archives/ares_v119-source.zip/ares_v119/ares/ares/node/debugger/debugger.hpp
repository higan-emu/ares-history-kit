struct Debugger : Object {
  DeclareClass(Debugger, "debugger")
  using Object::Object;
};
