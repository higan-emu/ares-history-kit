struct Video : Object {
  DeclareClass(Video, "video");
  using Object::Object;
};
