struct Peripheral : Object {
  DeclareClass(Peripheral, "peripheral")
  using Object::Object;
};
