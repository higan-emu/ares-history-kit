auto YM2610::serialize(serializer& s) -> void {
}
