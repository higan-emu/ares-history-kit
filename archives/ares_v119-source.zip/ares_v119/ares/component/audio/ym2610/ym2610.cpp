#include <ares/ares.hpp>
#include "ym2610.hpp"

namespace ares {

#include "serialization.cpp"

auto YM2610::power() -> void {
}

}
