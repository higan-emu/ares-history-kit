#include <ares/ares.hpp>
#include <ares/debug/debug.cpp>
#include <ares/node/node.cpp>
#include <ares/resource/resource.cpp>

namespace ares {

Platform* platform = nullptr;
bool _runAhead = false;

}
