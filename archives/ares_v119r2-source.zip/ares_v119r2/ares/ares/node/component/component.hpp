struct Component : Object {
  DeclareClass(Component, "component");
  using Object::Object;
};
