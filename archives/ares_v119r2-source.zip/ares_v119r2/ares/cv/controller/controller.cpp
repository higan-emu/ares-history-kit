#include <cv/cv.hpp>

namespace ares::ColecoVision {

#include "port.cpp"
#include "gamepad/gamepad.cpp"

}
