#include <fc/fc.hpp>

namespace ares::Famicom {

#include "port.cpp"
#include "family-keyboard/family-keyboard.cpp"

}
